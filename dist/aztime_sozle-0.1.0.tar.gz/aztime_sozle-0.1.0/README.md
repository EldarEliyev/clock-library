# aztime_sozle

Azərbaycan dilində verilmiş saatı (HH:MM) təbii şəkildə sözlərlə ifadə edən kiçik və sürətli Python kitabxanası.

## Quraşdırma

```bash
pip install aztime_sozle